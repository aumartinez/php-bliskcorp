<?php

interface Sanitize {
  
  public function sanitize_str($str);
  
}

?>