<?php

interface Errors {
  
  public function get_errors();
  
}

?>