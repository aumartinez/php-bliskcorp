<?php

interface Handlers {
  
  public function not_found();
  
}

?>