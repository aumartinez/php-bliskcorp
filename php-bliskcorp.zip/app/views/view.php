<?php

class View {
     
  public function render($view_name) {    
    echo $view_name;
  }
  
}

?>