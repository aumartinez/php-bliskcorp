//Main JS scripts

$(document).ready(function(){
  
  $("#modal .close").click(function(){
    $("video").get(0).pause();
  });
  
});